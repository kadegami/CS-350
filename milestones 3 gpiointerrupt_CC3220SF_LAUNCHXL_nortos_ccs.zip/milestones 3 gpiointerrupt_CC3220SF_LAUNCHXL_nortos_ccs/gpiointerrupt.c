/*
 * Karina Washington
 * October 1st , 2024
 * MILESTONE 3
 *
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
#include "ti_drivers_config.h"

/* Morse code timings in microseconds */
#define DOT_DURATION       500000  // 500 ms
#define DASH_DURATION      1500000 // 1500 ms
#define INTRA_CHAR_GAP     500000  // 500 ms
#define INTER_CHAR_GAP     1500000 // 1500 ms

/* Timer period in microseconds */
#define TIMER_PERIOD_US    500000  // 500 ms

/* Message definitions */
typedef enum {
    MESSAGE_SOS,
    MESSAGE_OK
} MessageType;

/* Morse code step definitions */
typedef struct {
    uint_least8_t led; // LED to control (CONFIG_GPIO_LED_0: Green, CONFIG_GPIO_LED_1: Red)
    bool state;         // true: ON, false: OFF
    int duration;       // Number of timer callbacks (each callback = 500 ms)
} MorseStep;

/* SOS: ... --- ... */
MorseStep SOS_steps[] = {
    /* S: ... */
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 1},   // Dot OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 1},   // Dot OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 3},   // Dot OFF (1500 ms inter-char gap)

    /* O: --- */
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 1},   // Dash OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 1},   // Dash OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 3},   // Dash OFF (1500 ms inter-char gap)

    /* S: ... */
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 1},   // Dot OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 1},   // Dot OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 3},   // Dot OFF (1500 ms inter-char gap)
};

#define SOS_TOTAL_STEPS (sizeof(SOS_steps)/sizeof(MorseStep))

/* OK: --- -.-- */
MorseStep OK_steps[] = {
    /* O: --- */
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 1},   // Dash OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 1},   // Dash OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 3},   // Dash OFF (1500 ms inter-char gap)

    /* K: -.-- */
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 1},   // Dash OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_0, true, 1},    // Dot ON (500 ms)
    {CONFIG_GPIO_LED_0, false, 1},   // Dot OFF (500 ms intra-char gap)
    {CONFIG_GPIO_LED_1, true, 3},    // Dash ON (1500 ms)
    {CONFIG_GPIO_LED_1, false, 3},   // Dash OFF (1500 ms inter-char gap)
};

#define OK_TOTAL_STEPS (sizeof(OK_steps)/sizeof(MorseStep))

/* Current message */
volatile MessageType currentMessage = MESSAGE_SOS;

/* Flag set by button press */
volatile bool buttonPressed = false;

/* State machine variables */
int currentStepIndex = 0;
int remainingSteps = 0;

/* Timer Handle */
Timer_Handle timer0;

/*
 *  ======== timerCallback ========
 *  Callback function for the Timer interrupt.
 *  This function is called every TIMER_PERIOD_US microseconds.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    /* Call the state machine */
    runStateMachine();
}

/*
 *  ======== runStateMachine ========
 *  Implements the state machine logic.
 *  It manages the blinking of SOS and OK messages based on the current message type.
 */
void runStateMachine(void)
{
    MorseStep *currentSteps;
    int totalSteps;

    /* Select the current message steps */
    if (currentMessage == MESSAGE_SOS) {
        currentSteps = SOS_steps;
        totalSteps = SOS_TOTAL_STEPS;
    } else {
        currentSteps = OK_steps;
        totalSteps = OK_TOTAL_STEPS;
    }

    /* If no current step is active, start the first step */
    if (remainingSteps <= 0) {
        if (currentStepIndex < totalSteps) {
            /* Execute current step */
            GPIO_write(currentSteps[currentStepIndex].led, currentSteps[currentStepIndex].state ? CONFIG_GPIO_LED_ON : CONFIG_GPIO_LED_OFF);
            /* Set remaining steps for this step */
            remainingSteps = currentSteps[currentStepIndex].duration;
            /* Move to next step */
            currentStepIndex++;
        } else {
            /* Completed the message */
            currentStepIndex = 0;
            /* Check if button was pressed to toggle message */
            if (buttonPressed) {
                buttonPressed = false;
                if (currentMessage == MESSAGE_SOS) {
                    currentMessage = MESSAGE_OK;
                } else {
                    currentMessage = MESSAGE_SOS;
                }
            }
        }
    }

    /* Decrement remaining steps */
    if (remainingSteps > 0) {
        remainingSteps--;
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  This function sets a flag indicating that the button was pressed.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Set button pressed flag */
    buttonPressed = true;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *  It toggles CONFIG_GPIO_LED_1 when the second button is pressed.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle an LED */
    GPIO_toggle(CONFIG_GPIO_LED_1);
}

/*
 *  ======== initTimer ========
 *  Initializes the Timer to call the state machine every TIMER_PERIOD_US microseconds.
 */
void initTimer(void)
{
    Timer_Handle myHandle;
    Timer_Params params;

    Timer_init();

    Timer_Params_init(&params);
    params.period = TIMER_PERIOD_US;      // Set timer period to 500,000 us (500 ms)
    params.periodUnits = Timer_PERIOD_US; // Timer period units in microseconds
    params.timerMode = Timer_CONTINUOUS_CALLBACK; // Continuous mode
    params.timerCallback = timerCallback;  // Callback function

    /* Open the Timer with CONFIG_TIMER_0 */
    myHandle = Timer_open(CONFIG_TIMER_0, &params);
    if (myHandle == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }

    /* Start the Timer */
    if (Timer_start(myHandle) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }

    /* Save the Timer handle */
    timer0 = myHandle;
}

/*
 *  ======== mainThread ========
 *  The main thread of the application.
 *  Initializes GPIO, Timer, configures LEDs and buttons, and starts the Timer.
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    Timer_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED 0 (Green) */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button 0 callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts for Button 0 */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
        /* Install Button1 callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        /* Enable interrupts for Button1 */
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    /* Initialize the Timer */
    initTimer();

    /* Run the state machine will be handled by the Timer callback */

    return (NULL);
}
